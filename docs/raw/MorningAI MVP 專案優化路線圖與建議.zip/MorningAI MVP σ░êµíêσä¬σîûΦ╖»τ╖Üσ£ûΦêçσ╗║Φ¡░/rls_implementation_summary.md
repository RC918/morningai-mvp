# Supabase `users` 表格 RLS 政策實作總結

## 概述

本報告總結了為 Supabase 多租戶應用程式中的 `public.users` 表格實作 Row Level Security (RLS) 政策的過程。此實作旨在確保資料隔離和安全存取控制，允許使用者僅能存取和修改其自身的資料。

## 實作步驟與結果

### 1. 啟用 `public.users` 表格的 RLS

首先，我們為 `public.users` 表格啟用了行級安全性。這一步驟是實作任何 RLS 政策的基礎，確保所有對該表格的存取都將受到定義政策的約束。

```sql
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
```

**結果：** `public.users` 表格已成功啟用 RLS。

### 2. 建立 `allow_own_user_read` 政策

此政策允許已驗證的使用者讀取其自身的 `users` 資料。我們將 `auth.uid()`（Supabase 提供的當前已驗證使用者 ID）與 `users` 表格中的 `id` 欄位進行比較。由於 `auth.uid()` 返回的是 UUID 類型，而 `id` 是整數類型，我們將兩者都轉換為文本類型進行比較，以避免類型不匹配錯誤。

```sql
CREATE POLICY allow_own_user_read ON public.users FOR SELECT TO authenticated USING (auth.uid()::text = id::text);
```

**結果：** 成功建立 `allow_own_user_read` 政策，確保使用者只能讀取自己的資料。

### 3. 建立 `allow_own_user_insert` 政策

此政策允許已驗證的使用者插入其自身的 `users` 資料。`WITH CHECK` 子句確保新插入的資料符合 `auth.uid() = id` 的條件，即使用者只能為自己的 ID 建立記錄。

```sql
CREATE POLICY allow_own_user_insert ON public.users FOR INSERT TO authenticated WITH CHECK (auth.uid()::text = id::text);
```

**結果：** 成功建立 `allow_own_user_insert` 政策，限制使用者只能插入自己的資料。

### 4. 建立 `allow_own_user_update` 政策

此政策允許已驗證的使用者更新其自身的 `users` 資料。`USING` 子句限制了可以更新的行，而 `WITH CHECK` 子句確保更新後的資料仍然符合使用者擁有該資料的條件。

```sql
CREATE POLICY allow_own_user_update ON public.users FOR UPDATE TO authenticated USING (auth.uid()::text = id::text) WITH CHECK (auth.uid()::text = id::text);
```

**結果：** 成功建立 `allow_own_user_update` 政策，確保使用者只能更新自己的資料。

### 5. 建立 `allow_own_user_delete` 政策

此政策允許已驗證的使用者刪除其自身的 `users` 資料。`USING` 子句確保只有使用者自己的記錄可以被刪除。

```sql
CREATE POLICY allow_own_user_delete ON public.users FOR DELETE TO authenticated USING (auth.uid()::text = id::text);
```

**結果：** 成功建立 `allow_own_user_delete` 政策，限制使用者只能刪除自己的資料。

### 6. 政策驗證

透過查詢 `pg_policies` 系統視圖，我們驗證了所有已建立的 RLS 政策。結果顯示所有政策均已正確配置，並應用於 `public.users` 表格。

```sql
SELECT policyname, permissive, roles, cmd, qual, with_check FROM pg_policies WHERE tablename = 'users';
```

**驗證結果：**

| policyname            | permissive | roles           | cmd    | qual                      | with_check                |
|-----------------------|------------|-----------------|--------|---------------------------|---------------------------|
| allow_own_user_read   | PERMISSIVE | {authenticated} | SELECT | ((auth.uid())::text = (id)::text) |                           |
| allow_own_user_insert | PERMISSIVE | {authenticated} | INSERT |                           | ((auth.uid())::text = (id)::text) |
| allow_own_user_update | PERMISSIVE | {authenticated} | UPDATE | ((auth.uid())::text = (id)::text) | ((auth.uid())::text = (id)::text) |
| allow_own_user_delete | PERMISSIVE | {authenticated} | DELETE | ((auth.uid())::text = (id)::text) |                           |

## 結論與後續步驟

至此，`public.users` 表格的 RLS 政策已成功配置，確保了多租戶應用程式中使用者資料的隔離和安全性。這些政策允許已驗證的使用者對其自身的資料進行讀取、插入、更新和刪除操作。

**後續步驟：**

1.  **整合應用程式邏輯：** 確保前端和後端應用程式邏輯與這些 RLS 政策協同工作，並在執行資料操作時使用已驗證的使用者會話。
2.  **測試：** 進行全面的整合測試和安全性測試，以驗證 RLS 政策在各種場景下（包括不同使用者角色和權限）的行為是否符合預期。
3.  **監控：** 實作資料庫活動監控，以追蹤 RLS 政策的執行情況並及時發現潛在的安全問題。
4.  **文件化：** 更新專案文件，詳細記錄 `public.users` 表格的 RLS 政策配置和設計決策。

此實作完成了 Phase 2 中關於 `users` 表格 RLS 配置的關鍵部分，為多租戶應用程式的資料層安全奠定了堅實基礎。



## 解決 `public.alembic_version` 表格的 RLS 錯誤

Supabase 的 Security Advisor 報告指出 `public.alembic_version` 表格的 RLS 未啟用。此表格通常用於追蹤資料庫遷移狀態，不直接包含敏感使用者資料，但為了符合 Supabase 的安全建議並消除錯誤提示，我們為其啟用了 RLS 並建立了一個允許已驗證使用者讀取的政策。

### 1. 啟用 `public.alembic_version` 表格的 RLS

```sql
ALTER TABLE public.alembic_version ENABLE ROW LEVEL SECURITY;
```

**結果：** `public.alembic_version` 表格已成功啟用 RLS。

### 2. 建立 `allow_authenticated_read` 政策

此政策允許所有已驗證的使用者讀取 `public.alembic_version` 表格的資料。由於此表格的性質，允許已驗證使用者讀取其內容是安全的，並且不會引入資料洩露風險。

```sql
CREATE POLICY allow_authenticated_read ON public.alembic_version FOR SELECT TO authenticated USING (true);
```

**結果：** 成功建立 `allow_authenticated_read` 政策，解決了 Security Advisor 的錯誤提示。
