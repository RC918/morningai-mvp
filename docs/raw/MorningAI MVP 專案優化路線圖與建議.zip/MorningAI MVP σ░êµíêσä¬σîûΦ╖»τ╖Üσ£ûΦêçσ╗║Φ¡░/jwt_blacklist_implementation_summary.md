# JWT 黑名單實作總結

## 概述

本報告詳細記錄了為多租戶應用程式實作 JSON Web Token (JWT) 黑名單功能的過程。此功能旨在提供令牌撤銷機制，以增強應用程式的安全性，允許在使用者登出或發生安全事件時立即使特定 JWT 失效。

## 實作方案研究

我們研究了多種 JWT 黑名單實作方案，包括基於資料庫、快取系統（如 Redis）以及短生命週期 JWT 結合刷新令牌的方法。綜合考慮效能、可擴展性和實施複雜度，我們選擇了使用 **Redis 快取系統**來儲存黑名單令牌。此方案利用 Redis 的高效能鍵值儲存和自動過期機制，以最小化對資料庫的負擔並確保快速的令牌撤銷檢查。

## 資料模型設計

JWT 黑名單的資料模型主要基於 Redis 的鍵值儲存特性。每個被列入黑名單的 JWT 都以一個鍵值對的形式儲存：

*   **鍵 (Key)：** `jwt:blacklist:<jti>`，其中 `<jti>` 是 JWT 的唯一識別碼 (JTI)。
*   **值 (Value)：** 簡單的字串 `true`，表示該令牌已被列入黑名單。
*   **過期時間 (TTL)：** 每個黑名單條目都設定一個過期時間，與被列入黑名單的 JWT 的原始過期時間 (exp claim) 相匹配。這確保了 Redis 會自動清理過期的黑名單條目，避免了黑名單的無限增長。

## 實作細節

JWT 黑名單功能主要透過修改 `apps/api/src/auth.py` 和 `apps/api/src/main.py` 檔案來實作：

### `auth.py` 的修改

1.  **導入必要的函式庫：** 引入 `uuid` 用於生成 JTI，`time` 用於計算 TTL，`jwt` 用於解碼令牌，`os` 和 `requests` 用於與 Upstash Redis REST API 互動。
2.  **`create_tokens` 函數修改：** 在生成 `access_token` 和 `refresh_token` 時，為其添加唯一的 `jti` (JWT ID) 聲明。這使得每個令牌都具有可追蹤的唯一識別碼。
3.  **`upstash_redis_command` 函數：** 實現了一個輔助函數，用於透過 HTTP 請求與 Upstash Redis REST API 進行互動。此函數負責發送 Redis 命令並解析其回應。
4.  **`blacklist_jwt` 函數：** 接收一個 JWT，解碼以提取其 `jti` 和 `exp` 聲明。然後計算剩餘的有效時間作為 TTL，並使用 `upstash_redis_command` 將 `jwt:blacklist:<jti>` 鍵值對儲存到 Redis 中。
5.  **`is_jwt_blacklisted` 函數：** 接收一個 JWT，解碼以提取其 `jti`。然後使用 `upstash_redis_command` 查詢 Redis，檢查 `jwt:blacklist:<jti>` 鍵是否存在，以判斷令牌是否已被列入黑名單。

### `main.py` 的修改

1.  **`logout` 路由修改：** 當使用者登出時，從請求頭中提取當前 JWT，並呼叫 `auth.blacklist_jwt` 函數將其加入黑名單。
2.  **`@app.before_request` 中間件：** 在每個請求處理之前，檢查請求頭中的 JWT 是否已被列入黑名單。如果 `auth.is_jwt_blacklisted` 返回 `True`，則拒絕請求並返回 401 Unauthorized 錯誤。
3.  **新增管理路由：** 為了未來擴展，添加了 `logout-all` 和 `revoke-token` 路由，儘管 `logout-all` 僅為簡化實作，實際應用中可能需要更複雜的令牌追蹤機制。

## 測試結果

我們透過一個 Python 測試腳本 (`test_jwt.py`) 驗證了 JWT 黑名單功能的有效性。測試步驟如下：

1.  **註冊新用戶：** 成功註冊 `testuser3`。
2.  **登入獲取令牌：** `testuser3` 成功登入並獲取了 `access_token`。
3.  **使用有效令牌存取受保護路由：** 使用獲取的 `access_token` 成功存取 `/auth/profile` 路由，狀態碼為 200。
4.  **登出並將令牌加入黑名單：** 呼叫 `/auth/logout` 路由，將 `access_token` 加入黑名單。日誌顯示 `JWT with JTI <jti> blacklisted for <ttl> seconds.`。
5.  **嘗試使用已加入黑名單的令牌：** 再次使用相同的 `access_token` 存取 `/auth/profile` 路由。應用程式返回狀態碼 401，回應內容為 `{"message": "Token has been revoked"}`。

**結論：** 測試結果證明 JWT 黑名單功能已成功實作，已撤銷的令牌被正確識別並拒絕存取，達到了預期的安全效果。

## 後續步驟

根據您提供的「下一步計劃」，我們將繼續推進以下安全改進措施：

### 短期改進
1.  **密碼政策：** 添加密碼強度要求，例如最小長度、包含大小寫字母、數字和特殊字元等。
2.  **帳戶鎖定：** 實施失敗登入嘗試限制，防止暴力破解攻擊。
3.  **電子郵件驗證：** 添加電子郵件驗證流程，確保用戶註冊時提供的電子郵件地址是有效的。

### 中期改進
1.  **雙因素認證：** 實施 2FA 支援，為用戶提供額外的安全層。
2.  **OAuth 整合：** 支援第三方登入，如 Google、GitHub 等，提升用戶體驗和安全性。
3.  **角色權限：** 實施基於角色的存取控制 (RBAC)，精細化管理用戶對資源的存取權限。
4.  **審計日誌：** 記錄詳細的用戶活動，以便進行安全審計和問題追蹤。

### 長期改進
1.  **單一登入 (SSO)：** 企業級 SSO 整合，簡化多應用程式的身份驗證流程。
2.  **進階威脅防護：** 實作異常行為檢測，主動識別和防禦潛在的安全威脅。
3.  **合規性：** 支援 GDPR、SOC 2 等合規性要求，確保應用程式符合相關法規標準。

這些步驟將逐步提升應用程式的整體安全性和健壯性。
