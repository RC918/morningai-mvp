
# 🌅 MorningAI – Mermaid Architecture & Roadmap (EN)

This document provides **Mermaid-based** diagrams for quick sharing in Notion/GitHub/Wikis.

---

## 1) High-Level System Architecture

```mermaid
flowchart LR
  subgraph Client["Client & Channels"]
    WebConsole["HITL Web Console (Next.js + shadcn/ui)"]
    Channels["LINE / Telegram / Slack / WhatsApp / WeChat"]
  end

  subgraph Gateway["Gateway Layer"]
    APIGW["API Gateway (Rate Limit, AuthN/Z, Blacklist)"]
    WebhookOrch["Webhook Orchestrator"]
  end

  subgraph Adapter["Adapter Layer"]
    MsgAdapters["Messaging Adapters"]
    SaaSAdapters["SaaS Adapters (Notion/Drive/Zapier ...)"]
  end

  subgraph AIEngine["AI Engine Layer"]
    Orchestrator["LangGraph Orchestrator"]
    Agents["Specialized Agents\n(Content/Growth/Ad Buyer/CodeWriter/AutoQA)"]
  end

  subgraph Data["Data Layer"]
    Supabase["Supabase (Postgres + RLS)"]
    Redis["Redis (Sessions/Lockout/JWT Blacklist/Rate Limit)"]
    Storage["S3/Cloud Storage"]
    Metrics["Metrics & Logs (Sentry/Grafana/Prometheus)"]
  end

  subgraph Billing["Billing & Identity"]
    Auth["Auth (JWT, MFA, Account Lockout)"]
    BillingSys["Stripe / TapPay"]
    RBAC["RBAC / Tenants"]
  end

  Channels --> WebhookOrch
  WebConsole --> APIGW
  WebhookOrch --> APIGW
  APIGW --> Adapter
  Adapter --> Orchestrator
  Orchestrator --> Agents
  Agents --> Supabase
  Agents --> Storage
  APIGW --> Auth
  Auth --> Redis
  APIGW --> RBAC
  APIGW --> BillingSys
  Supabase --> Metrics
  APIGW --> Metrics
  Orchestrator --> Metrics
```

---

## 2) Multi‑Tenant Data Isolation (RLS Overview)

```mermaid
erDiagram
  TENANT ||--o{ USER : has
  TENANT ||--o{ PROJECT : owns
  USER ||--o{ TASK : creates
  PROJECT ||--o{ TASK : contains

  TENANT {
    uuid id PK
    text name
  }
  USER {
    uuid id PK
    uuid tenant_id FK
    text email
    role rbac_role
  }
  PROJECT {
    uuid id PK
    uuid tenant_id FK
    text name
  }
  TASK {
    uuid id PK
    uuid tenant_id FK
    uuid project_id FK
    text status
  }
```

> **RLS Policy Principle:** `tenant_id = auth.jwt().tenant_id` AND role‑based predicates for admin-only operations.

---

## 3) Authentication & Security Flow

```mermaid
sequenceDiagram
  participant U as User
  participant API as API Gateway
  participant AUTH as Auth Service (JWT/MFA/Lockout)
  participant R as Redis
  participant DB as Supabase (RLS)

  U->>API: POST /auth/login (email, password)
  API->>AUTH: Verify credentials
  AUTH->>R: Check lockout counter
  R-->>AUTH: attempts / lockout TTL
  AUTH-->>API: Access+Refresh JWT (with tenant_id) or Lockout error
  API->>DB: Query with RLS (tenant-scoped)
  API->>R: Check JWT blacklist (revoke JTI?)
  DB-->>API: Data (filtered by RLS)
  API-->>U: Response
```

---

## 4) Orchestration DAG Lifecycle

```mermaid
flowchart TD
  A[Webhook / User Action] --> B[Task Intake]
  B --> C[Validate & Enrich (Tenant Context, RBAC)]
  C --> D{Routing}
  D -->|Simple| E[Direct Agent Call]
  D -->|Complex| F[LangGraph DAG Execution]
  F --> G[Parallel/Sequential Agent Steps]
  G --> H[Write Results to DB/Storage]
  H --> I[Emit Events / Logs / Metrics]
  I --> J[Notify HITL Console / Webhooks]
```

---

## 5) MVP Phased Roadmap (Swimlanes)

```mermaid
gantt
  dateFormat  YYYY-MM-DD
  title MorningAI MVP Roadmap

  section Phase 0 – Infrastructure
  Monorepo & CI/CD                :done,   p0a, 2025-09-01, 7d
  Auth/RLS/Blacklist/Lockout      :active, p0b, 2025-09-05, 10d
  UI Tokens & Components          :        p0c, 2025-09-10, 10d

  section Phase 1 – MVP Launch
  Multi-tenant + Referral         :        p1a, 2025-09-18, 10d
  HITL Console (Dashboard)        :        p1b, 2025-09-18, 12d
  Billing (Stripe/TapPay)         :        p1c, 2025-09-20, 10d
  Monitoring & Logging            :        p1d, 2025-09-20, 10d

  section Phase 2 – Orchestration
  DAG Orchestrator + Spec         :        p2a, 2025-10-02, 12d
  Core Agents Online              :        p2b, 2025-10-04, 14d
  End-to-end Webhook→HITL Loop    :        p2c, 2025-10-06, 12d
  i18n Enhancements               :        p2d, 2025-10-06, 10d

  section Phase 3 – Business Layer
  Marketplace & Integrations      :        p3a, 2025-10-20, 14d
  Compliance (GDPR/ISO prep)      :        p3b, 2025-10-22, 14d
  Multi-region Deployment         :        p3c, 2025-10-24, 14d
```

---

## 6) Handoff Package Checklist (per Phase)

```mermaid
mindmap
  root((Handoff Package))
    Design
      Figma flows
      HITL mockups
      Tokens & components
    Docs
      API Spec (OpenAPI)
      Security Reports (JWT/RLS/Lockout)
      Runbooks & Playbooks
    Code
      Monorepo skeleton
      CI/CD pipelines
      Env templates & secrets map
    Evidence
      Deploy URL & health checks
      Test coverage & E2E logs
      Commit SHA & changelog
```

---

## 7) Risks & Mitigations (Condensed)
- **Template lock-in** → Keep Tailwind + shadcn as the base; layer Mosaic only for layout/navigation.
- **Security gaps** → Enforce rate limiting, lockout, JWT blacklist, audit logs; add MFA later.
- **Data isolation** → RLS everywhere with `tenant_id`; admin actions behind stricter policies.
- **Scale & HA** → Plan Redis cluster, DB HA, and multi-region in Phase 3.
- **Upgrades** → Fork third-party templates, manage diffs via patches, and pin dependencies.

---

**End of document.**
