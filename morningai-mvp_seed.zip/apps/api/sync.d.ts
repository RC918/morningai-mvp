import { Output, Options } from "../types";
export declare function sync<TOutput extends Output>(root: string, options: Options): TOutput;
